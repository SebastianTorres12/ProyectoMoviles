package com.example.proyecto_negocios_ra

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
